# API_NAA

Local NAA API for saving and querying demo chat history.

This project uses an in-memory database for local development. No external database connection string, log database, private hospital package source, or project-level NuGet package reference is required.

## Run

```powershell
dotnet run --project .\src\API_NAA\API_NAA.csproj --launch-profile http
```

Default URL: `http://localhost:5210`
