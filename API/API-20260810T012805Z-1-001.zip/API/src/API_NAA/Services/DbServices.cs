using API_NAA.Constants;
using API_NAA.Dtos.Input.Create;
using API_NAA.Dtos.Input.Query;
using API_NAA.Dtos.Output.Origin;
using API_NAA.Interfaces;
using ResponseModel;
using static ResponseModel.ResponseMapper;

namespace API_NAA.Services;

public class DbServices : IDbServices
{
    private readonly object _syncRoot = new();
    private readonly List<HistoryResponseDto> _histories = new();

    public Task<ResponseModel<HistoryResponseDto>> SaveHistoryAsync(HistoryCreateDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Account) ||
            string.IsNullOrWhiteSpace(dto.QuestionText) ||
            string.IsNullOrWhiteSpace(dto.AnswerText) ||
            string.IsNullOrWhiteSpace(dto.OriginCode))
        {
            return Task.FromResult(GenerateErrorResponse<HistoryResponseDto>(
                "account, questionText, answerText, originCode are required"));
        }

        var history = new HistoryResponseDto
        {
            UniqueId = Guid.NewGuid().ToString(),
            Account = dto.Account,
            ChatTitle = dto.ChatTitle,
            OriginCode = dto.OriginCode,
            QuestionText = dto.QuestionText,
            AnswerText = dto.AnswerText,
            InsertDt = DateTime.Now
        };

        lock (_syncRoot)
        {
            _histories.Add(history);
        }

        return Task.FromResult(new[] { history }.ToResponse(DbConstant.InsertSuccess, DbConstant.InsertError));
    }

    public Task<ResponseModel<HistoryResponseDto>> GetHistoryByAccountAsync(HistoryQueryDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Account))
        {
            return Task.FromResult(GenerateErrorResponse<HistoryResponseDto>("account is required"));
        }

        List<HistoryResponseDto> result;
        lock (_syncRoot)
        {
            result = _histories
                .Where(x => string.Equals(x.Account, dto.Account, StringComparison.OrdinalIgnoreCase))
                .Where(x => string.IsNullOrWhiteSpace(dto.OriginCode) ||
                    string.Equals(x.OriginCode, dto.OriginCode, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(x => x.InsertDt)
                .ToList();
        }

        return Task.FromResult(result.ToResponse(DbConstant.QuerySuccess, DbConstant.QueryNoData));
    }
}
